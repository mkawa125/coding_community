<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('modals.confirm_delete_notes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-sm-11 offset-1">
        <div class=" main-content-head" style=" margin: 10px 0 0 0">
            <div class="row" style="padding: 0; margin: 0">
                <div class="col-md-12 head-column" style="padding: 0">
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active"
                           style="padding: 10px 20px 10px 20px" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Home</a>
                        <a class="nav-item nav-link"
                           style="padding: 10px 20px 10px 20px" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Profile</a>
                        <a class="nav-item nav-link"
                           style="padding: 10px 20px 10px 20px" id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Contact</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-content-notes" style="padding: 25px 45px 45px 45px">
            <?php if($data): ?>
                <div class="row">
                    <div class="col-sm-12">
                        <a href="#" class="details-head"><strong><?php echo e($data->notes_title); ?></strong></a>
                        <span class="category-details"><a href="#" style="color: chocolate"><?php echo e($data->notes_category); ?></a></span>
                    </div>
                </div>
                <div class="">
                    <?php echo $data->notes_body; ?>

                    <img src="<?php echo e(asset('images/sample-image.png')); ?>" alt="Chicago" width="100%" height="250" style="margin-bottom: 10px">
                    <span><strong><?php echo e($data->notes_add_date); ?></strong></span>
                    <span><strong style="color: cadetblue">Author: </strong> <a href="#"><?php echo e($data->name); ?> <?php echo e($data->surname); ?></a>, <a href="#" style="color: coral">Web Programmer</a></span>
                </div>
                <div class="action">
                    <div class="btn-group">
                        <a href="<?php echo e(url('notes/edit')); ?>" class="btn btn-success"><i class="fa fa-edit"></i></a>
                        <?php if($data->notes_accessibility == 'public'): ?>
                            <a class="btn btn-info btn-xs" title="make this public">
                                <i class="fa fa-eye"></i>
                            </a>
                        <?php else: ?>
                            <a class="btn btn-warning btn-xs" title="make this notes private">
                                <i class="fa fa-eye-slash"></i>
                            </a>
                        <?php endif; ?>
                        <button type="button" class="btn btn-danger btn-xs" onclick="showModal('confirm_delete_notes')">
                            <i class="fa fa-trash"></i>
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

































































    
        
            
                
            
            
                
                    
                    
                    
                        
                            
                        
                    
                    
                
                
            

        
    
    
        
            

                
                    
                        
                            
                            
                        
                    
                    
                        
                        
                        
                        
                    
                    
                        
                            
                            
                                
                                    
                                
                            
                                
                                    
                                
                            
                            
                                
                            
                        
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>