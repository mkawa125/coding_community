
<div id="copyright text-right footer">
    <div id="copyright text-right"> © Copyright 2018 Mkawa Coding community, Dar es salaam Tanzania </div>
     <ul class="list-inline">
         <li class="list-inline-item">
             <a class="#" href="https://www.facebook.com/papaa.mukuru" title="facebook">
                 <i class="fa fa-facebook"></i>
             </a>
         </li>
         <li class="list-inline-item">
             <a class="#" href="https://www.instagram.com/papaa__mukuru/" title="Instagram">
                 <i class="fa fa-instagram"></i>
             </a>
         </li>
         <li class="list-inline-item">
             <a class="#" href="#" title="Linkedin">
                 <i class="fa fa-linkedin"></i>
             </a>
         </li>
         <li class="list-inline-item" title="twitter">
             <a class="#" href="https://twitter.com/mkawa95">
                 <i class="fa fa-twitter-square"></i>
             </a>
         </li>
         <li class="list-inline-item" title="0717495198">
             <a class="#" href="#">
                 <i class="fa fa-whatsapp"></i>
             </a>
         </li>
     </ul>

</div>

